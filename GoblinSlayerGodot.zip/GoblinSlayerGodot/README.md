# Goblin Slayer: Rise of the Dark King

A self-contained Godot 4 project built for a hackathon, with procedural 3D arenas and gameplay systems. No external model downloads are required.

## Run it
1. Install **Godot 4.3 or newer** (Godot 4.x recommended).
2. Unzip this project.
3. In Godot Project Manager choose **Import** and select `project.godot`.
4. Press **F6/F5** or click Run.

## Controls
- WASD: move
- Mouse: rotate the hero/camera
- Left mouse: quick sword attack
- Right mouse: heavy attack (costs stamina)
- Space: jump
- Shift: sprint (uses stamina)
- Ctrl: dodge/roll (stamina cost; temporary invulnerability)
- Q: block
- Esc: pause

## Levels
1. Forgotten Forest — forest arena with pine trees
2. Cursed Village — ruined house blocks and village props
3. Dark Caverns — crystals and rock formations
4. Goblin Fortress — fortress towers
5. Dark Kingdom — dark spires and final boss

Each level has regular goblins and an arena boss. Defeat all foes to clear it and unlock the next level. Level Select allows direct testing of any arena.

## Features
- Procedural, self-contained 3D visuals and arenas
- Third-person movement, sprint, jump, dodge, blocking
- Light and heavy attacks, stamina and health
- Chasing enemy AI, enemy attacks and boss health tracking
- Five levels with increasing enemy health/damage
- Main menu, level select, controls page, pause, retry, game over and victory flow
- Continue/save using `user://save.json`
- HUD and level/objective labels
- Lightweight generated audio effects

## Architecture
- `Main.tscn`: entry scene
- `scripts/game.gd`: world/arena creation, gameplay, combat, AI, menus, HUD, save data
- `audio/`: WAV effects

## Note
This is a hackathon-ready playable foundation, not a AAA production: art is procedural primitives rather than supplied models, and the character motion/attacks are gameplay actions without authored skeletal animations. The prompt attachment contained the specification only; no original Blender/GLB assets were available to reuse.
