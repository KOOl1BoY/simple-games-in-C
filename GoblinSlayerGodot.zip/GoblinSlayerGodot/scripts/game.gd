extends Node3D

const LEVELS = ["THE FORGOTTEN FOREST", "THE CURSED VILLAGE", "THE DARK CAVERNS", "THE GOBLIN FORTRESS", "THE DARK KINGDOM"]
const COLORS = [Color(0.12,0.25,0.14), Color(0.28,0.19,0.14), Color(0.12,0.12,0.25), Color(0.25,0.24,0.22), Color(0.22,0.04,0.08)]
var level_index := 0
var player: CharacterBody3D
var camera: Camera3D
var enemies: Array[Node3D] = []
var player_hp := 100.0
var stamina := 100.0
var score := 0
var kills := 0
var game_active := false
var paused := false
var boss_hp := 0.0
var attack_timer := 0.0
var invuln := 0.0
var menu_layer: CanvasLayer
var hud_layer: CanvasLayer
var hp_bar: ProgressBar
var stamina_bar: ProgressBar
var boss_bar: ProgressBar
var status_label: Label
var objective_label: Label
var sound_player: AudioStreamPlayer
var ambience_player: AudioStreamPlayer
var menu_panel: VBoxContainer
var rng := RandomNumberGenerator.new()

func _ready():
 rng.randomize()
 _setup_audio()
 show_menu()

func _setup_audio():
 sound_player = AudioStreamPlayer.new(); add_child(sound_player)
 ambience_player = AudioStreamPlayer.new(); add_child(ambience_player)

func _mat(c: Color, rough:=0.9, metallic:=0.0):
 var m=StandardMaterial3D.new(); m.albedo_color=c; m.roughness=rough; m.metallic=metallic
 return m

func _box(parent, pos: Vector3, size: Vector3, color: Color, name="Block"):
 var mesh=MeshInstance3D.new(); mesh.name=name
 var bm=BoxMesh.new(); bm.size=size; mesh.mesh=bm; mesh.material_override=_mat(color)
 mesh.position=pos; parent.add_child(mesh)
 var body=StaticBody3D.new(); body.position=pos; parent.add_child(body)
 var shape=CollisionShape3D.new(); var cs=BoxShape3D.new(); cs.size=size; shape.shape=cs; body.add_child(shape)
 return mesh

func _sphere(parent,pos,size,color,name="Orb"):
 var m=MeshInstance3D.new(); m.name=name; var sm=SphereMesh.new(); sm.radius=size; sm.height=size*2; m.mesh=sm; m.material_override=_mat(color); m.position=pos; parent.add_child(m); return m

func _cylinder(parent,pos,r,h,color,name="Pillar"):
 var m=MeshInstance3D.new(); m.name=name; var cm=CylinderMesh.new(); cm.top_radius=r; cm.bottom_radius=r; cm.height=h; m.mesh=cm; m.material_override=_mat(color); m.position=pos; parent.add_child(m); return m

func _tree(parent,pos):
 _cylinder(parent,pos+Vector3(0,1,0),0.23,2.0,Color(0.23,0.12,0.07),"Pine trunk")
 for i in range(3):
  var cone=MeshInstance3D.new(); var mesh=PrismMesh.new(); cone.mesh=mesh; cone.material_override=_mat(Color(0.07,0.2,0.12)); cone.position=pos+Vector3(0,1.4+i*0.65,0); cone.scale=Vector3(1.25-i*0.2,1.5,1.25-i*0.2); parent.add_child(cone)

func _make_world():
 for child in get_children():
  if child is Node3D and child != player: child.queue_free()
 var env=WorldEnvironment.new(); var e=Environment.new(); e.background_mode=Environment.BG_SKY; e.sky=Sky.new(); e.sky.sky_material=ProceduralSkyMaterial.new(); e.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR; e.ambient_light_color=Color(0.5,0.55,0.62); e.ambient_light_energy=0.65; e.tonemap_mode=Environment.TONE_MAPPER_FILMIC; e.fog_enabled=true; e.fog_light_color=COLORS[level_index].lightened(0.25); e.fog_density=0.018; env.environment=e; add_child(env)
 var sun=DirectionalLight3D.new(); sun.rotation_degrees=Vector3(-48,-35,0); sun.light_energy=1.4; sun.shadow_enabled=true; add_child(sun)
 var world=Node3D.new(); world.name="LevelWorld"; add_child(world)
 _box(world,Vector3(0,-0.5,0),Vector3(48,1,48),COLORS[level_index],"Arena floor")
 # Environmental variations
 for i in range(22):
  var x=rng.randf_range(-21,21); var z=rng.randf_range(-21,21)
  if level_index==0: _tree(world,Vector3(x,0,z))
  elif level_index==1:
   _box(world,Vector3(x,1,z),Vector3(rng.randf_range(2,4),2,rng.randf_range(2,4)),Color(0.25,0.18,0.13),"Village ruin")
   _box(world,Vector3(x,2.3,z),Vector3(2.4,0.3,2.4),Color(0.12,0.1,0.1),"Roof")
  elif level_index==2:
   _cylinder(world,Vector3(x,2,z),rng.randf_range(0.5,1.5),rng.randf_range(2,5),Color(0.22,0.24,0.3),"Crystal rock")
   _sphere(world,Vector3(x,2.5,z),0.22,Color(0.1,0.7,1.0),"Glowing crystal")
  elif level_index==3:
   _box(world,Vector3(x,2,z),Vector3(2,4,2),Color(0.35,0.33,0.3),"Fortress tower")
  else:
   _cylinder(world,Vector3(x,2,z),rng.randf_range(1,2),4,Color(0.18,0.13,0.18),"Dark spire")
 # torches and details around arena
 for x in [-12,12]:
  for z in [-12,12]:
   _cylinder(world,Vector3(x,1,z),0.16,2,Color(0.22,0.16,0.1),"Torch stand")
   var flame=_sphere(world,Vector3(x,2.2,z),0.35,Color(1,0.45,0.08),"Flame")
   var light=OmniLight3D.new(); light.position=Vector3(x,2.3,z); light.light_color=Color(1,0.45,0.15); light.light_energy=2; light.omni_range=8; world.add_child(light)
 # gate / destination landmark
 _box(world,Vector3(0,2,-19),Vector3(7,4,0.7),Color(0.18,0.16,0.15),"Level gate")
 _box(world,Vector3(0,4.5,-19),Vector3(8,0.6,1),Color(0.6,0.38,0.12),"Gate crest")
 _spawn_enemies()

func _spawn_enemies():
 enemies.clear()
 var count=3+level_index*2
 for i in range(count):
  var enemy=_create_enemy(false); enemy.position=Vector3(rng.randf_range(-13,13),0,rng.randf_range(-13,13)); enemies.append(enemy)
 var boss=_create_enemy(true); boss.position=Vector3(0,0,-13); enemies.append(boss); boss_hp=120+level_index*55

func _create_enemy(is_boss: bool):
 var enemy=CharacterBody3D.new(); enemy.name="Goblin King" if (is_boss and level_index==4) else ("Boss" if is_boss else "Goblin")
 enemy.set_meta("boss",is_boss); enemy.set_meta("hp", 120+level_index*55 if is_boss else 40+level_index*18); enemy.set_meta("attack_cd",rng.randf_range(0.5,2.0)); enemy.set_meta("dead",false); enemy.set_meta("speed",2.5+level_index*0.25 if is_boss else 2.8+level_index*0.2)
 var body=MeshInstance3D.new(); var bm=CapsuleMesh.new(); bm.radius=0.45 if not is_boss else 0.85; bm.height=1.6 if not is_boss else 2.7; body.mesh=bm; body.material_override=_mat(Color(0.3,0.55,0.18) if not is_boss else Color(0.35,0.08,0.12)); body.position.y=0.9 if not is_boss else 1.35; enemy.add_child(body)
 _sphere(enemy,Vector3(0,1.65 if not is_boss else 2.3,0),0.36 if not is_boss else 0.62,Color(0.35,0.6,0.18) if not is_boss else Color(0.45,0.12,0.15),"Head")
 for side in [-1,1]:
  _sphere(enemy,Vector3(side*0.18,1.7 if not is_boss else 2.4,-0.3),0.08,Color(1,0.1,0.05),"Eye")
  _box(enemy,Vector3(side*0.55,0.9,0),Vector3(0.18,0.75,0.18),Color(0.24,0.25,0.2),"Arm")
 _box(enemy,Vector3(0.55,1.1,-0.25),Vector3(0.12,0.65,0.12),Color(0.55,0.52,0.45),"Weapon")
 var col=CollisionShape3D.new(); var shape=CapsuleShape3D.new(); shape.radius=0.45 if not is_boss else 0.85; shape.height=1.8 if not is_boss else 2.8; col.shape=shape; col.position.y=shape.height/2; enemy.add_child(col)
 add_child(enemy); return enemy

func _create_player():
 player=CharacterBody3D.new(); player.name="Hero"; player.position=Vector3(0,0,5); add_child(player)
 var body=MeshInstance3D.new(); var cm=CapsuleMesh.new(); cm.radius=0.38; cm.height=1.8; body.mesh=cm; body.material_override=_mat(Color(0.18,0.22,0.3)); body.position.y=0.9; player.add_child(body)
 _sphere(player,Vector3(0,1.65,0),0.34,Color(0.55,0.42,0.3),"Helmetless head")
 _box(player,Vector3(0.48,1.0,-0.15),Vector3(0.12,0.8,0.12),Color(0.75,0.75,0.8),"Sword blade")
 var shape=CollisionShape3D.new(); var capsule=CapsuleShape3D.new(); capsule.radius=0.38; capsule.height=1.8; shape.shape=capsule; shape.position.y=0.9; player.add_child(shape)
 camera=Camera3D.new(); camera.position=Vector3(0,4,8); camera.rotation_degrees=Vector3(-15,0,0); camera.current=true; player.add_child(camera)

func new_game():
 level_index=0; player_hp=100; stamina=100; score=0; kills=0; _load_save(); _start_level()

func _start_level():
 game_active=true; paused=false; if player: player.queue_free()
 for n in enemies:
  if is_instance_valid(n): n.queue_free()
 enemies.clear(); _make_world(); _create_player(); _build_hud();
 if menu_layer: menu_layer.queue_free(); menu_layer=null
 Input.mouse_mode=Input.MOUSE_MODE_CAPTURED

func _build_hud():
 if hud_layer: hud_layer.queue_free()
 hud_layer=CanvasLayer.new(); add_child(hud_layer)
 var root=Control.new(); root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); hud_layer.add_child(root)
 var panel=Panel.new(); panel.position=Vector2(24,24); panel.size=Vector2(340,118); panel.modulate=Color(0.08,0.08,0.1,0.82); root.add_child(panel)
 var v=VBoxContainer.new(); v.position=Vector2(16,12); v.size=Vector2(310,100); panel.add_child(v)
 var title=Label.new(); title.text="HERO  |  LEVEL %d" % (level_index+1); title.add_theme_font_size_override("font_size",20); v.add_child(title)
 hp_bar=ProgressBar.new(); hp_bar.max_value=100; hp_bar.value=player_hp; hp_bar.show_percentage=false; hp_bar.custom_minimum_size.y=18; v.add_child(hp_bar)
 stamina_bar=ProgressBar.new(); stamina_bar.max_value=100; stamina_bar.value=stamina; stamina_bar.show_percentage=false; stamina_bar.custom_minimum_size.y=14; v.add_child(stamina_bar)
 objective_label=Label.new(); objective_label.text="Objective: Defeat all enemies"; objective_label.position=Vector2(28,155); objective_label.add_theme_font_size_override("font_size",18); root.add_child(objective_label)
 status_label=Label.new(); status_label.text="WASD move • Mouse aim • LMB attack • RMB heavy • Shift sprint • Ctrl dodge • Q block • Esc pause"; status_label.anchor_left=0; status_label.anchor_top=1; status_label.anchor_bottom=1; status_label.position=Vector2(24,-45); status_label.add_theme_font_size_override("font_size",16); root.add_child(status_label)
 boss_bar=ProgressBar.new(); boss_bar.max_value=100; boss_bar.value=100; boss_bar.position=Vector2(390,30); boss_bar.size=Vector2(500,22); root.add_child(boss_bar)
 var levelname=Label.new(); levelname.text=LEVELS[level_index]; levelname.position=Vector2(430,58); levelname.add_theme_font_size_override("font_size",22); root.add_child(levelname)

func show_menu():
 game_active=false; paused=false; Input.mouse_mode=Input.MOUSE_MODE_VISIBLE
 if hud_layer: hud_layer.queue_free(); hud_layer=null
 if menu_layer: menu_layer.queue_free()
 menu_layer=CanvasLayer.new(); add_child(menu_layer)
 var bg=ColorRect.new(); bg.color=Color(0.015,0.02,0.035,1); bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); menu_layer.add_child(bg)
 # visual backdrop
 var title=Label.new(); title.text="GOBLIN SLAYER\nRISE OF THE DARK KING"; title.position=Vector2(90,90); title.add_theme_font_size_override("font_size",54); title.add_theme_color_override("font_color",Color(0.85,0.72,0.52)); menu_layer.add_child(title)
 var tagline=Label.new(); tagline.text="A DARK FANTASY ACTION ADVENTURE"; tagline.position=Vector2(95,240); tagline.add_theme_font_size_override("font_size",19); menu_layer.add_child(tagline)
 var buttons=VBoxContainer.new(); buttons.position=Vector2(100,320); buttons.size=Vector2(360,330); buttons.add_theme_constant_override("separation",12); menu_layer.add_child(buttons)
 _menu_button(buttons,"NEW GAME",func(): new_game())
 _menu_button(buttons,"CONTINUE",func(): _continue_game())
 _menu_button(buttons,"LEVEL SELECT",func(): _level_select())
 _menu_button(buttons,"CONTROLS",func(): _show_controls())
 _menu_button(buttons,"QUIT",func(): get_tree().quit())
 var footer=Label.new(); footer.text="Made for the Hackathon • Godot 4"; footer.position=Vector2(95,670); menu_layer.add_child(footer)

func _menu_button(parent,text,callback):
 var b=Button.new(); b.text=text; b.custom_minimum_size=Vector2(320,54); b.add_theme_font_size_override("font_size",22); b.pressed.connect(callback); parent.add_child(b); return b

func _continue_game():
 var data=_read_save(); if data.is_empty(): new_game(); else: level_index=int(data.get("level",0)); player_hp=float(data.get("hp",100)); score=int(data.get("score",0)); kills=int(data.get("kills",0)); _start_level()

func _level_select():
 if menu_layer: menu_layer.queue_free()
 menu_layer=CanvasLayer.new(); add_child(menu_layer); var bg=ColorRect.new(); bg.color=Color(0.02,0.02,0.04); bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); menu_layer.add_child(bg)
 var title=Label.new(); title.text="CHOOSE YOUR DESTINY"; title.position=Vector2(90,70); title.add_theme_font_size_override("font_size",40); menu_layer.add_child(title)
 var v=VBoxContainer.new(); v.position=Vector2(100,150); menu_layer.add_child(v)
 for i in range(5): _menu_button(v,"%d  •  %s" % [i+1,LEVELS[i]],func(): level_index=i; player_hp=100; _start_level())
 _menu_button(v,"BACK",func(): show_menu())

func _show_controls():
 if menu_layer: menu_layer.queue_free()
 menu_layer=CanvasLayer.new(); add_child(menu_layer); var bg=ColorRect.new(); bg.color=Color(0.02,0.02,0.04); bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); menu_layer.add_child(bg)
 var text=Label.new(); text.text="CONTROLS\n\nWASD — Move\nMouse — Rotate camera\nLeft click — Quick sword attack\nRight click — Heavy attack\nSpace — Jump\nShift — Sprint\nCtrl — Dodge\nQ — Block\nEsc — Pause\n\nDefeat enemies and the arena champion to advance."; text.position=Vector2(100,90); text.add_theme_font_size_override("font_size",28); menu_layer.add_child(text)
 _menu_button(menu_layer,"BACK",func(): show_menu()).position=Vector2(100,560)

func _pause_menu():
 paused=true; game_active=false; Input.mouse_mode=Input.MOUSE_MODE_VISIBLE
 var layer=CanvasLayer.new(); layer.name="PauseLayer"; add_child(layer)
 var shade=ColorRect.new(); shade.color=Color(0,0,0,0.7); shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); layer.add_child(shade)
 var v=VBoxContainer.new(); v.position=Vector2(460,210); v.size=Vector2(360,300); layer.add_child(v)
 var t=Label.new(); t.text="PAUSED"; t.add_theme_font_size_override("font_size",40); t.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; v.add_child(t)
 _menu_button(v,"RESUME",func(): layer.queue_free(); paused=false; game_active=true; Input.mouse_mode=Input.MOUSE_MODE_CAPTURED)
 _menu_button(v,"RESTART LEVEL",func(): layer.queue_free(); player_hp=100; _start_level())
 _menu_button(v,"SAVE & MAIN MENU",func(): _save_game(); layer.queue_free(); show_menu())
 _menu_button(v,"QUIT",func(): get_tree().quit())

func _input(event):
 if game_active and event is InputEventMouseMotion and camera: player.rotate_y(-event.relative.x*0.003); camera.rotate_x(-event.relative.y*0.003); camera.rotation.x=clamp(camera.rotation.x,-0.75,0.25)
 if event.is_action_pressed("pause") and game_active: _pause_menu()

func _physics_process(delta):
 if not game_active or paused or not player: return
 attack_timer=max(0,attack_timer-delta); invuln=max(0,invuln-delta)
 var direction=Vector3.ZERO
 direction-=player.transform.basis.z*Input.get_axis("move_back","move_forward")
 direction+=player.transform.basis.x*Input.get_axis("move_left","move_right")
 direction=direction.normalized()
 var speed=7.0 if Input.is_action_pressed("sprint") and stamina>1 else 4.6
 if speed>5: stamina=max(0,stamina-delta*24)
 else: stamina=min(100,stamina+delta*17)
 player.velocity.x=direction.x*speed; player.velocity.z=direction.z*speed
 if not player.is_on_floor(): player.velocity.y-=22*delta
 elif Input.is_action_just_pressed("jump"): player.velocity.y=7.5
 if Input.is_action_just_pressed("dodge") and stamina>=25: stamina-=25; player.velocity.x=-player.transform.basis.z.x*12; player.velocity.z=-player.transform.basis.z.z*12; invuln=0.5
 player.move_and_slide()
 if Input.is_action_just_pressed("attack"): _attack(false)
 if Input.is_action_just_pressed("heavy"): _attack(true)
 _update_enemies(delta)
 if hp_bar: hp_bar.value=player_hp
 if stamina_bar: stamina_bar.value=stamina
 if boss_bar: boss_bar.value=boss_hp
 if enemies.filter(func(e): return is_instance_valid(e) and not e.get_meta("dead",true)).is_empty(): _level_complete()

func _attack(heavy):
 if attack_timer>0: return
 attack_timer=0.65 if heavy else 0.38
 _play_sfx("heavy.wav" if heavy else "swing.wav")
 if heavy: stamina=max(0,stamina-18)
 var target=null; var closest=4.0 if heavy else 3.0
 for e in enemies:
  if not is_instance_valid(e) or e.get_meta("dead",false): continue
  var d=player.global_position.distance_to(e.global_position)
  if d<closest: closest=d; target=e
 if target:
  var damage=28+level_index*3 if heavy else 18+level_index*2
  target.set_meta("hp",target.get_meta("hp")-damage); target.velocity= (target.global_position-player.global_position).normalized()*5
  score+=damage
  if target.get_meta("hp")<=0: target.set_meta("dead",true); target.queue_free(); kills+=1; score+=100
  if target.get_meta("boss",false): boss_hp=max(0,target.get_meta("hp"))

func _update_enemies(delta):
 for e in enemies:
  if not is_instance_valid(e) or e.get_meta("dead",false): continue
  var to_player=player.global_position-e.global_position; var dist=to_player.length(); e.set_meta("attack_cd",float(e.get_meta("attack_cd"))-delta)
  if dist>2.1:
   var dir=to_player.normalized(); e.velocity.x=dir.x*float(e.get_meta("speed")); e.velocity.z=dir.z*float(e.get_meta("speed")); e.look_at(Vector3(player.position.x,e.position.y,player.position.z),Vector3.UP)
  else:
   e.velocity.x=0; e.velocity.z=0
   if e.get_meta("attack_cd")<=0:
    e.set_meta("attack_cd",1.4 if e.get_meta("boss") else 1.8)
    if invuln<=0 and not Input.is_action_pressed("block"):
     player_hp-=12+level_index*3
     _play_sfx("hit.wav")
     if player_hp<=0: _game_over()
  if not e.is_on_floor(): e.velocity.y-=20*delta
  e.move_and_slide()

func _level_complete():
 game_active=false; Input.mouse_mode=Input.MOUSE_MODE_VISIBLE; _save_game()
 var layer=CanvasLayer.new(); add_child(layer); var shade=ColorRect.new(); shade.color=Color(0,0,0,0.8); shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); layer.add_child(shade)
 var v=VBoxContainer.new(); v.position=Vector2(390,200); v.size=Vector2(500,350); layer.add_child(v)
 var t=Label.new(); t.text="LEVEL CLEARED!"; t.add_theme_font_size_override("font_size",42); t.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; v.add_child(t)
 var info=Label.new(); info.text="Score: %d   •   Goblins defeated: %d" % [score,kills]; info.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; v.add_child(info)
 if level_index<4: _menu_button(v,"NEXT LEVEL",func(): layer.queue_free(); level_index+=1; player_hp=min(100,player_hp+25); _start_level())
 else: _menu_button(v,"CLAIM VICTORY",func(): layer.queue_free(); _credits())
 _menu_button(v,"MAIN MENU",func(): layer.queue_free(); show_menu())

func _game_over():
 game_active=false; Input.mouse_mode=Input.MOUSE_MODE_VISIBLE
 var layer=CanvasLayer.new(); add_child(layer); var shade=ColorRect.new(); shade.color=Color(0,0,0,0.85); shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); layer.add_child(shade)
 var v=VBoxContainer.new(); v.position=Vector2(450,230); v.size=Vector2(380,280); layer.add_child(v)
 var t=Label.new(); t.text="YOU HAVE FALLEN"; t.add_theme_font_size_override("font_size",36); v.add_child(t)
 _menu_button(v,"RETRY",func(): layer.queue_free(); player_hp=100; _start_level())
 _menu_button(v,"MAIN MENU",func(): layer.queue_free(); show_menu())

func _credits():
 show_menu(); var label=Label.new(); label.text="\n\nTHE KING IS DEAD. THE REALM IS FREE.\n\nThanks for playing."; label.position=Vector2(600,180); label.add_theme_font_size_override("font_size",26); menu_layer.add_child(label)

func _save_game():
 var f=FileAccess.open("user://save.json",FileAccess.WRITE); if f: f.store_string(JSON.stringify({"level":level_index,"hp":player_hp,"score":score,"kills":kills}))

func _read_save():
 if not FileAccess.file_exists("user://save.json"): return {}
 var f=FileAccess.open("user://save.json",FileAccess.READ); var parsed=JSON.parse_string(f.get_as_text()); return parsed if parsed is Dictionary else {}

func _load_save():
 var data=_read_save(); if not data.is_empty(): level_index=max(level_index,int(data.get("level",0)))

func _play_sfx(file_name):
 var stream=load("res://audio/"+file_name)
 if stream:
  sound_player.stream=stream; sound_player.play()

func _setup_audio_placeholder(): pass
